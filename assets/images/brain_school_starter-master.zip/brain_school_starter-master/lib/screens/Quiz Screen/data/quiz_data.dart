class QuizData{
  final String answer;


  QuizData(this.answer);
}

List  <QuizData> quiz =[
  QuizData('A- Stefanie Taylor', ),
  QuizData('B- Stefanie Taylor'),
  QuizData('C- Stefanie Taylor'),
  QuizData('D- Stefanie Taylor'),

];